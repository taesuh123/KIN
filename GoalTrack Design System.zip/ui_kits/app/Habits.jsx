function Habits({events}) {
  const titleCount = {};
  events.forEach(e => { const t = e.t.toLowerCase(); titleCount[t] = (titleCount[t]||0)+1; });
  const top = Object.entries(titleCount).sort((a,b)=>b[1]-a[1]).slice(0,6);

  // 10-week heatmap, deterministic
  const weeks = 10;
  const heatRows = [];
  for (let w=0; w<weeks; w++) {
    const col = [];
    for (let d=0; d<7; d++) {
      const r = (Math.sin(w*7+d*1.3)+1)/2;
      const lvl = r<.4?0:r<.6?1:r<.78?2:r<.92?3:4;
      col.push(lvl);
    }
    heatRows.push(col);
  }

  const catCounts = {};
  events.forEach(e => catCounts[e.cat] = (catCounts[e.cat]||0)+1);
  const total = events.length || 1;
  const catRows = Object.entries(catCounts).sort((a,b)=>b[1]-a[1]);

  return (
    <>
      <div className="gt-page-h"><Title prefix="My" accent="Habits" /></div>
      <Panel title="Activity — last 10 weeks">
        <div className="gt-heat">
          {heatRows.map((col, i) => (
            <div key={i} className="gt-heat-col">
              {col.map((lvl, j) => <div key={j} className={`gt-heat-cell ${lvl?`l${lvl}`:''}`} />)}
            </div>
          ))}
        </div>
        <div style={{display:'flex',alignItems:'center',gap:5,justifyContent:'flex-end',marginTop:10,font:'400 11px/1 var(--font-sans)',color:'var(--text-light)'}}>
          <span>Less</span>
          {['','l1','l2','l3','l4'].map((c,i)=><div key={i} className={`gt-heat-cell ${c}`} />)}
          <span>More</span>
        </div>
      </Panel>
      <div className="gt-two">
        <Panel title="Most frequent activities">
          {top.map(([n, c], i) => (
            <div key={n} className="gt-act">
              <span className="gt-act-r">{i+1}</span>
              <span className="gt-act-n">{n.charAt(0).toUpperCase()+n.slice(1)}</span>
              <div className="gt-act-bw"><div className="gt-act-bf" style={{width: `${Math.round(c/top[0][1]*100)}%`}}/></div>
              <span className="gt-act-c">{c}x</span>
            </div>
          ))}
        </Panel>
        <Panel title="Time by category">
          <div className="gt-cleg">
            {catRows.map(([k, c]) => {
              const dot = (window.CATS[k] || {}).dot || '#999';
              const label = (window.CATS[k] || {}).label || k;
              const pct = Math.round(c/total*100);
              return (
                <div key={k} className="gt-cleg-row">
                  <span className="gt-cleg-d" style={{background: dot}} />
                  <span className="gt-cleg-n">{label}</span>
                  <div className="gt-cleg-bw"><div className="gt-cleg-bf" style={{width: `${pct}%`, background: dot}}/></div>
                  <span className="gt-cleg-p">{pct}%</span>
                </div>
              );
            })}
          </div>
        </Panel>
      </div>
    </>
  );
}
window.Habits = Habits;
