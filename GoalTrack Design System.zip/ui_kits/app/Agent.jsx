function Agent({goals, events}) {
  const [draft, setDraft] = React.useState('');
  const [msgs, setMsgs] = React.useState([
    {role:'agent', text: `I am reading your ${goals.length} goals, ${events.length} events, and 18 goal-linked sessions. Ask me what to do next, how progress is going, or which skills to focus on.`},
    {role:'user',  text: 'How am I doing on my fitness goals?'},
    {role:'agent', html: `<strong>Reach 200 lbs</strong> has the clearest momentum with 6 linked sessions and about 8 hours logged. Feedback: 4 events are still unlinked, so your progress page may be undercounting your effort. Next move: schedule the next 3 gym events now and attach skills like Strength Training and Discipline.`},
  ]);

  function send() {
    if (!draft.trim()) return;
    setMsgs([...msgs, {role:'user', text: draft.trim()}, {role:'agent', text: 'Thinking through your record now…'}]);
    setDraft('');
  }

  return (
    <div style={{maxWidth:1180, width:'100%', display:'flex', flexDirection:'column', gap:14}}>
      <div className="gt-page-h"><Title prefix="Personal" accent="Agent" /></div>
      <div className="gt-chat">
        <div className="gt-chat-h">
          <div className="gt-chat-t">Your Personal Agent</div>
          <div className="gt-chat-st">Live</div>
        </div>
        <div className="gt-chat-ctrls">
          <select className="gt-chat-sel" defaultValue="cur">
            <option value="cur">Current chat</option>
            <option>Last week's check-in</option>
          </select>
          <button className="gt-chat-new">New Chat</button>
        </div>
        <div className="gt-chat-msgs">
          {msgs.map((m, i) => (
            <div key={i} className={`gt-msg ${m.role}`} dangerouslySetInnerHTML={m.html ? {__html: m.html} : undefined}>
              {m.html ? null : m.text}
            </div>
          ))}
        </div>
        <div className="gt-chat-input">
          <input value={draft} onChange={e => setDraft(e.target.value)} placeholder="Ask for suggestions or feedback..." onKeyDown={e => e.key === 'Enter' && send()} />
          <button className="gt-chat-send" onClick={send}>Send</button>
        </div>
      </div>
    </div>
  );
}
window.Agent = Agent;
