// GoalTrack — small primitives shared across UI kit components
function EyebrowLabel({children, large}) {
  return <div className={large ? 'gt-eyebrow' : 'gt-panel-t'}>{children}</div>;
}

function Pill({tone='work', selected=true, children}) {
  return <span className={`gt-ev ${tone}`} style={{padding:'5px 12px', fontSize:12, opacity: selected ? 1 : .65}}>{children}</span>;
}

function Panel({title, children, style}) {
  return (
    <div className="gt-panel" style={style}>
      {title ? <div className="gt-panel-t">{title}</div> : null}
      {children}
    </div>
  );
}

function StatCard({label, num, sub, barPct, barColor}) {
  return (
    <div className="gt-stat">
      <div className="gt-stat-l">{label}</div>
      <div className="gt-stat-n">{num}</div>
      {sub ? <div className="gt-stat-s">{sub}</div> : null}
      {barPct != null ? <div className="gt-stat-bar"><div style={{width:`${barPct}%`, background: barColor || 'var(--accent)'}} /></div> : null}
    </div>
  );
}

function Title({prefix, accent}) {
  return <div className="gt-title">{prefix} <span className="a">{accent}</span></div>;
}

window.EyebrowLabel = EyebrowLabel;
window.Pill = Pill;
window.Panel = Panel;
window.StatCard = StatCard;
window.Title = Title;
