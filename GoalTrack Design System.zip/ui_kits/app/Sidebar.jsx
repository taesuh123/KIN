const CATS = {
  work:    {label:'Work',     dot:'#534AB7'},
  school:  {label:'School',   dot:'#185FA5'},
  fitness: {label:'Fitness',  dot:'#2C5F2E'},
  personal:{label:'Personal', dot:'#BA7517'},
  finance: {label:'Finance',  dot:'#993C1D'},
};

function Sidebar({today, events}) {
  // mini cal: October 2025 with `today` highlighted
  const y = today.getFullYear(), m = today.getMonth();
  const first = new Date(y, m, 1);
  const start = first.getDay();
  const last = new Date(y, m+1, 0).getDate();
  const cells = [];
  for (let i=0; i<start; i++) cells.push({d: 0, other:true});
  for (let d=1; d<=last; d++) cells.push({d, other:false});
  while (cells.length % 7) cells.push({d:0, other:true});

  const eventDates = new Set(events.map(e => e.day));
  const monthName = today.toLocaleString('en-US', {month:'long', year:'numeric'});

  const catCounts = Object.keys(CATS).map(k => [k, events.filter(e=>e.cat===k).length]);

  const upcoming = [
    {t:'Bench press · push day',   when:'Today · 6:00pm–7:00pm',     cat:'fitness'},
    {t:'Linguistics outline',      when:'Tomorrow · 4:00pm–5:30pm',  cat:'school'},
    {t:'Coffee with Maya',         when:'In 3 days · 11:00am',       cat:'personal'},
  ];

  return (
    <aside className="gt-side">
      <div>
        <div className="gt-eyebrow">Navigate</div>
        <div className="gt-mini-head">
          <span className="gt-mini-title">{monthName}</span>
          <div className="gt-mini-nav"><button>‹</button><button>›</button></div>
        </div>
        <div className="gt-mini-grid">
          {['S','M','T','W','T','F','S'].map((l,i) => <div key={i} className="gt-mini-dl">{l}</div>)}
          {cells.map((c, i) => {
            const isToday = c.d === today.getDate() && !c.other;
            const has = eventDates.has(c.d);
            return (
              <div key={i} className={`gt-mini-d ${c.other?'other':''} ${isToday?'today':''} ${has && !isToday ?'has-event':''}`}>{c.d || ''}</div>
            );
          })}
        </div>
      </div>
      <div>
        <div className="gt-eyebrow">Categories</div>
        <div className="gt-cat-list">
          {catCounts.map(([k,c]) => (
            <div key={k} className="gt-cat">
              <span className="gt-cat-dot" style={{background: CATS[k].dot}} />
              <span>{CATS[k].label}</span>
              <span className="gt-cat-cnt">{c}</span>
            </div>
          ))}
        </div>
      </div>
      <div>
        <div className="gt-eyebrow">Coming up</div>
        <div className="gt-up-list">
          {upcoming.map((u, i) => (
            <div key={i} className="gt-up" style={{borderLeftColor: CATS[u.cat].dot}}>
              <div className="gt-up-t">{u.t}</div>
              <div className="gt-up-m">{u.when}</div>
            </div>
          ))}
        </div>
      </div>
    </aside>
  );
}
window.Sidebar = Sidebar;
window.CATS = CATS;
