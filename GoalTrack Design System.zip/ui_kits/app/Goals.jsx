function Goals({goals, setGoals}) {
  const total = goals.length;
  const done = goals.filter(g => g.done).length;
  const sessions = 18;

  function toggle(id) {
    setGoals(goals.map(g => g.id === id ? {...g, done: !g.done} : g));
  }

  const cols = [
    {key:'personal',     label:'Personal'},
    {key:'academic',     label:'Academic'},
    {key:'professional', label:'Professional'},
  ];

  return (
    <>
      <div className="gt-page-h">
        <Title prefix="My" accent="Goals" />
        <button className="gt-cta">+ Add Goal</button>
      </div>
      <div className="gt-stats">
        <StatCard label="Total Goals"     num={total}      sub={`${done} completed`} barPct={total ? Math.round(done/total*100) : 0} />
        <StatCard label="Active"          num={total-done} sub="in progress" />
        <StatCard label="Sessions Logged" num={sessions}   sub="events tied to goals" />
      </div>
      <div className="gt-cols">
        {cols.map(col => {
          const list = goals.filter(g => g.type === col.key);
          return (
            <div key={col.key} className="gt-col">
              <div className="gt-col-h">
                <span className={`gt-col-t ${col.key}`}>{col.label}</span>
                <span className="gt-col-c">{list.length}</span>
              </div>
              <div className="gt-glist">
                {list.length === 0 ? <div style={{padding:'14px 12px', textAlign:'center', color:'var(--text-light)', font:'400 13px/1 var(--font-sans)'}}>No {col.label.toLowerCase()} goals yet</div> : null}
                {list.map(g => (
                  <div key={g.id} className={`gt-gc ${g.done?'done':''}`}>
                    <div className="gt-gc-t">
                      <span className={`gt-check ${g.done?'on':''}`} onClick={() => toggle(g.id)}>{g.done ? '✓' : ''}</span>
                      <span>{g.title}</span>
                    </div>
                    {g.desc ? <div className="gt-gc-d">{g.desc}</div> : null}
                    {g.linked ? <div className="gt-gc-l">● {g.linked} session{g.linked!==1?'s':''} logged</div> : null}
                  </div>
                ))}
              </div>
              <button className="gt-add">+ Add {col.label.toLowerCase()} goal</button>
            </div>
          );
        })}
      </div>
    </>
  );
}
window.Goals = Goals;
