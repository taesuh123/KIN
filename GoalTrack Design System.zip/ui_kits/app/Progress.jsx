function Progress({goals, events}) {
  const insights = [
    {bg:'#EAF3DE', em:'📊', t:'Most active: Fitness',  d:'14 events where you invest the most time.'},
    {bg:'#FAEEDA', em:'⚠️', t:'2 goals with no sessions yet', d:'Read 12 books, Save $5,000 by July.'},
    {bg:'#FAECE7', em:'🔥', t:'5-day streak',          d:'Something logged every day for 5 days.'},
    {bg:'#E6F1FB', em:'⏱',  t:'42 hours logged total', d:`Across ${events.length} calendar events.`},
  ];
  const linked = 18;
  const hours = 42;

  const pgCards = goals.filter(g => !g.done).slice(0,3).map(g => ({
    title: g.title, type: g.type, pct: g.pct || 60,
    insight: g.insight || `Currently 218 lbs. Target: 200 lbs. Moved 4.0 lbs (on track ↓). 18.0 lbs to go.`,
    sessions: ['Bench press · Oct 12','Squat day · Oct 14','Push day · Oct 16'],
  }));

  return (
    <>
      <div className="gt-page-h"><Title prefix="My" accent="Progress" /></div>

      <div style={{display:'grid', gridTemplateColumns:'minmax(0,1.4fr) minmax(280px,.75fr)', gap:18}}>
        <Panel title="Recommended Next Actions">
          <div style={{display:'grid', gridTemplateColumns:'repeat(3,1fr)', gap:10}}>
            {[
              {t:'personal', label:'Personal',     msg:<>Schedule one small session for <strong>Reach 200 lbs</strong>.</>},
              {t:'academic', label:'Academic',     msg:<>Add a measurable note to your next <strong>Read 12 books</strong> session.</>},
              {t:'professional',label:'Professional',msg:<>Add a professional goal to track this area.</>},
            ].map(c => (
              <div key={c.t} style={{background:'var(--bg)', border:'.5px solid var(--border)', borderRadius:12, padding:12}}>
                <div className={`gt-col-t ${c.t}`} style={{marginBottom:8}}>{c.label}</div>
                <div className="gt-ai-item">{c.msg}</div>
              </div>
            ))}
          </div>
        </Panel>
        <Panel title="Quick Insights">
          {insights.map((r, i) => (
            <div key={i} className="gt-ins">
              <div className="gt-ins-i" style={{background: r.bg}}>{r.em}</div>
              <div style={{flex:1}}>
                <div className="gt-ins-t">{r.t}</div>
                <div className="gt-ins-d">{r.d}</div>
              </div>
            </div>
          ))}
        </Panel>
      </div>

      <div className="gt-ai">
        <div className="gt-ai-h">
          <div>
            <div className="gt-ai-t">AI <span className="a">Insights</span></div>
            <div className="gt-ai-s">A private on-device synthesis of everything submitted so far: goals, sessions, categories, skills, dates, durations, and notes.</div>
          </div>
          <div className="gt-ai-bdg">Local analysis</div>
        </div>
        <div className="gt-ai-grid">
          <div className="gt-ai-met"><div className="gt-ai-met-n">{goals.length}</div><div className="gt-ai-met-l">Goals</div></div>
          <div className="gt-ai-met"><div className="gt-ai-met-n">{events.length}</div><div className="gt-ai-met-l">Sessions</div></div>
          <div className="gt-ai-met"><div className="gt-ai-met-n">{hours}</div><div className="gt-ai-met-l">Hours</div></div>
          <div className="gt-ai-met"><div className="gt-ai-met-n">{linked}</div><div className="gt-ai-met-l">Linked</div></div>
        </div>
        <div className="gt-ai-section">
          <div className="gt-ai-st">Overall Read</div>
          <div style={{font:'400 13.5px/1.6 var(--font-sans)', color:'var(--text-muted)'}}>
            Your record shows {events.length} logged sessions across {goals.length} goals, with about {hours} hours captured. Most of the useful progress signal is coming from {linked} goal-linked sessions. Your strongest time investment is <strong>Fitness</strong>.
          </div>
        </div>
        <div className="gt-ai-section">
          <div className="gt-ai-st">Goal Momentum</div>
          <div className="gt-ai-list">
            <div className="gt-ai-item"><strong>Reach 200 lbs</strong> has the clearest momentum with 6 linked sessions and about 8 hours logged.</div>
            <div className="gt-ai-item">Goals that need a first concrete session: <strong>Read 12 books</strong>, <strong>Save $5,000 by July</strong>.</div>
          </div>
        </div>
        <div className="gt-ai-section">
          <div className="gt-ai-st">Skills Signal</div>
          <div className="gt-ai-chips">
            {[['Strength Training',6],['Discipline',5],['Time Management',4],['Cardio',3],['Reading',2]].map(([s,c]) => (
              <span key={s} className="gt-ai-chip">{s} {c}x</span>
            ))}
          </div>
        </div>
      </div>

      <div style={{display:'flex', flexDirection:'column', gap:14}}>
        {pgCards.map(c => (
          <div key={c.title} className="gt-pg">
            <div className="gt-pg-h">
              <div className="gt-pg-t">{c.title}</div>
              <span className={`gt-pg-tp ${c.type}`}>{c.type[0].toUpperCase()+c.type.slice(1)}</span>
            </div>
            <div className="gt-pg-i" dangerouslySetInnerHTML={{__html: c.insight.replace(/\b(218 lbs|200 lbs|4.0 lbs|18.0 lbs)\b/g,'<strong>$1</strong>')}} />
            <div className="gt-pg-bw"><div className={`gt-pg-bf ${c.pct>=75?'green':c.pct>=40?'blue':'warn'}`} style={{width:`${c.pct}%`}}/></div>
            <div className="gt-pg-m"><span>{c.pct}% progress</span><span>{c.sessions.length} sessions</span></div>
            <div className="gt-pg-sx">
              {c.sessions.map(s => <span key={s} className="gt-pg-sc">{s}</span>)}
            </div>
          </div>
        ))}
      </div>
    </>
  );
}
window.Progress = Progress;
