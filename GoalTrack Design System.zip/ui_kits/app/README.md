# GoalTrack App — UI Kit

Pixel-faithful recreation of the GoalTrack app, broken into reusable React components. Sourced directly from `source/index.html`.

## Files
- `index.html` — interactive demo: nav between **Calendar / Goals / Habits / Progress / Agent** with sample data baked in.
- `Nav.jsx` — top nav (wordmark, 5 tabs, primary CTA).
- `Sidebar.jsx` — calendar sidebar (mini-cal, categories, coming up).
- `Calendar.jsx` — month grid + toolbar.
- `Goals.jsx` — 3-column kanban + stat strip.
- `Habits.jsx` — heatmap + frequency bars + category legend.
- `Progress.jsx` — AI insights panel + quick insights + per-goal progress cards.
- `Agent.jsx` — agent chat shell.
- `Bits.jsx` — small primitives: `Pill`, `Chip`, `EyebrowLabel`, `StatCard`, `Panel`, `IconBtn`.

## Notes / shortcuts
- All components are **visual/interactive recreations**, not production code. State lives in `App` and is in-memory only.
- Sample data is seeded so the demo looks alive on first load.
- Modals from the original (Add Event, Add Goal, Day list, Event detail) are represented by an Add Event modal stub; the focus is on the five tabs themselves.
- Skill suggestions, AI agent reply branching, and progress arithmetic are simplified — the visuals are accurate.
