function Nav({active, setActive}) {
  const tabs = ['Calendar','Goals','Habits','Progress','Agent'];
  const cta = active === 'Calendar' ? '+ Add Event' : null;
  return (
    <nav className="gt-nav">
      <a className="gt-nav-brand" href="#">goal<span className="a">track</span></a>
      <div className="gt-tabs">
        {tabs.map(t => (
          <button key={t} className={`gt-tab ${t === active ? 'active' : ''}`} onClick={() => setActive(t)}>{t}</button>
        ))}
      </div>
      <div>
        {cta ? <button className="gt-cta">{cta}</button> : <span style={{display:'inline-block',width:140}}/>}
      </div>
    </nav>
  );
}
window.Nav = Nav;
