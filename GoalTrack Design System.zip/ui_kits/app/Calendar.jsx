function Calendar({today, events}) {
  const y = today.getFullYear(), m = today.getMonth();
  const first = new Date(y, m, 1);
  const start = first.getDay();
  const last = new Date(y, m+1, 0).getDate();
  const cells = [];
  for (let i=0; i<start; i++) {
    const d = new Date(y, m, -(start-1-i));
    cells.push({date:d, other:true});
  }
  for (let d=1; d<=last; d++) cells.push({date:new Date(y,m,d), other:false});
  while (cells.length % 7) {
    const last = cells[cells.length-1].date;
    const d = new Date(last); d.setDate(d.getDate()+1);
    cells.push({date:d, other:true});
  }

  const monthName = today.toLocaleString('en-US', {month:'long'});

  return (
    <div className="gt-cal">
      <div className="gt-cal-tb">
        <div className="gt-cal-nav">
          <button className="gt-cal-btn">‹</button>
          <button className="gt-cal-btn">›</button>
        </div>
        <div className="gt-cal-mt">{monthName} <span className="yr">{y}</span></div>
        <button className="gt-today">Today</button>
        <div className="gt-vt">
          <button className="active">Month</button>
          <button>Week</button>
        </div>
      </div>
      <div className="gt-month">
        <div className="gt-mlbls">{['Sun','Mon','Tue','Wed','Thu','Fri','Sat'].map(l => <div key={l}>{l}</div>)}</div>
        <div className="gt-mgrid">
          {cells.map((c, i) => {
            const isToday = c.date.getTime() === today.getTime();
            const dayEvs = c.other ? [] : events.filter(e => e.day === c.date.getDate());
            return (
              <div key={i} className={`gt-mc ${c.other?'other':''} ${isToday?'today':''}`}>
                <div className="gt-mc-n">{c.date.getDate()}</div>
                {dayEvs.slice(0,3).map((e, j) => <div key={j} className={`gt-ev ${e.cat}`}>{e.t}</div>)}
                {dayEvs.length > 3 ? <div style={{font:'700 10px/1.05 var(--font-sans)', color:'var(--text-light)', padding:'0 6px'}}>+{dayEvs.length-3} more</div> : null}
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}
window.Calendar = Calendar;
